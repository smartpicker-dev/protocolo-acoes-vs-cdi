# Referencias (ABNT) — Fontes de metodologia (IBOV e S&P 500)

B3 S.A. – BRASIL, BOLSA, BALCAO. **Metodologia do Indice Bovespa (Ibovespa)**. Sao Paulo: B3, ago. 2020. Disponivel em: https://www.b3.com.br/data/files/9C/15/76/F6/3F6947102255C247AC094EA8/IBOV-Metodologia-pt-br__Novo_.pdf. Acesso em: 16 fev. 2026.

B3 S.A. – BRASIL, BOLSA, BALCAO. **Manual de definicoes e procedimentos de Indices da B3 (Conceitos e Procedimentos)**. Sao Paulo: B3, fev. 2023. Disponivel em: https://www.b3.com.br/data/files/CA/A5/9F/28/14F35810F534EB48AC094EA8/Manual%20de%20defini%C3%A7%C3%B5es%20e%20procedimentos%20de%20%C3%8Dndices-PT.pdf. Acesso em: 16 fev. 2026.

B3 S.A. – BRASIL, BOLSA, BALCAO. **Historico de adequacoes metodologicas dos Indices da B3**. Sao Paulo: B3, fev. 2021. Disponivel em: https://www.b3.com.br/data/files/A0/12/BB/92/12AC77101FCDCB77AC094EA8/Historico-das-Adequacoes-Metodologicas%20Port%20Fev21.pdf. Acesso em: 16 fev. 2026.

S&P DOW JONES INDICES. **S&P 500(R)**. [S.l.]: S&P Global, [s.d.]. Disponivel em: https://www.spglobal.com/spdji/en/indices/equity/sp-500/. Acesso em: 16 fev. 2026.

S&P DOW JONES INDICES. **S&P U.S. Indices Methodology**. [S.l.]: S&P Global, [s.d.]. Disponivel em: https://www.spglobal.com/spdji/en/documents/methodologies/methodology-sp-us-indices.pdf. Acesso em: 16 fev. 2026.

S&P DOW JONES INDICES. **S&P 500: The Gauge of the U.S. Large-Cap Market**. [S.l.]: S&P Global, [s.d.]. Disponivel em: https://www.spglobal.com/spdji/en/documents/additional-material/sp-500-brochure.pdf. Acesso em: 16 fev. 2026.
