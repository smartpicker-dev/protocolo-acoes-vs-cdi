# Fontes — Metodologia de Índices (IBOV e S&P 500) — pacote separado (v13b1)

Data de coleta/arquivamento: 2026-02-16 (UTC-03:00)

Este pacote **NAO altera** o data-freeze do estudo. Ele adiciona apenas evidencias documentais (fontes) para embasar a secao "Dados e Fontes".

## Observacao importante (arquivamento)
Alguns documentos foram salvos como **PDFs arquivados (extratos)**: sao arquivos gerados para o study package contendo trechos selecionados + URL oficial + data de coleta.
Para auditoria completa, consulte o **URL oficial** indicado no proprio PDF.

## Conteudo (arquivo -> o que prova)

| Arquivo | O que prova (uso no paper) | URL oficial |
|---|---|---|
| ARCHIVE_B3_Ibovespa_Metodologia_extratos_2026-02-16.pdf | Ibovespa e **indice de retorno total (TR)**; criterios de inclusao e ponderacao (free float com cap) | https://www.b3.com.br/data/files/9C/15/76/F6/3F6947102255C247AC094EA8/IBOV-Metodologia-pt-br__Novo_.pdf |
| ARCHIVE_B3_Manual_Indices_TR_definicao_extratos_2026-02-16.pdf | Definicao de **indice de retorno total (TR)** e itens incorporados (dividendos, JCP liquido, direitos, bonificacao/desdobramento etc.) | https://www.b3.com.br/data/files/CA/A5/9F/28/14F35810F534EB48AC094EA8/Manual%20de%20defini%C3%A7%C3%B5es%20e%20procedimentos%20de%20%C3%8Dndices-PT.pdf |
| ARCHIVE_B3_Historico_Adequacoes_Ibovespa_2013_2014_extratos_2026-02-16.pdf | Historico oficial de adequacoes metodologicas do Ibovespa e implementacao em 2013/2014 | https://www.b3.com.br/data/files/A0/12/BB/92/12AC77101FCDCB77AC094EA8/Historico-das-Adequacoes-Metodologicas%20Port%20Fev21.pdf |
| ARCHIVE_SPDJI_SP500_pagina_oficial_extratos_2026-02-16.pdf | Descricao oficial do S&P 500 e referencia para documentos de metodologia/eligibility | https://www.spglobal.com/spdji/en/indices/equity/sp-500/ |
| REFERENCIAS_ABNT.md | Referencias prontas (ABNT) para colar no paper | — |

## Checksums
- checksums_pdfs_sha256.txt (incluido no ZIP) contem SHA256 dos PDFs arquivados deste pacote.
- checksums.txt (fora do ZIP) contem SHA256 do ZIP e replica os SHA256 dos PDFs.

